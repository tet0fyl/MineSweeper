package Models;


public class Case {
    boolean jaiUneBombe;

    Case(boolean jaiUneBombe) {
        this.jaiUneBombe = jaiUneBombe;
    }
}
