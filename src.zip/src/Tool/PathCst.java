package Tool;

public class PathCst {
    public static final String urlBombImg = "Asset/img/bomb.png";
    public static final String urlExplosionGif = "Asset/img/explosion.gif";
    public static final String urlScreenBreak = "Asset/img/screenBreak.png";
    public static final String fontSpongeBob = "../Asset/font/SpongeBob.ttf";
    public static final String urlParallaxBg = "Asset/img/parallax/";
    public static final String urlMainBg = "Asset/img/mainBg.png";
    public static final String urlData = "src/Data/score.csv";

}
